from django.test import TestCase, Client
from django.urls import reverse
from .models import Booking
from datetime import date
import json


class BookingModelTest(TestCase):
    def setUp(self):
        self.booking = Booking.objects.create(
            first_name="John",
            reservation_date="2024-12-13",
            reservation_slot=18
        )

    def test_booking_creation(self):
        self.assertEqual(self.booking.first_name, "John")
        self.assertEqual(str(self.booking.reservation_date), "2024-12-13")
        self.assertEqual(self.booking.reservation_slot, 18)

    def test_booking_str(self):
        expected = "John - 2024-12-13 at 18:00"
        self.assertEqual(str(self.booking), expected)

    def test_unique_constraint(self):
        """Test that duplicate bookings for same date/time are not allowed"""
        with self.assertRaises(Exception):
            Booking.objects.create(
                first_name="Jane",
                reservation_date="2024-12-13",
                reservation_slot=18
            )


class BookingViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.booking = Booking.objects.create(
            first_name="John",
            reservation_date="2024-12-13",
            reservation_slot=18
        )

    def test_home_page(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)

    def test_book_page(self):
        response = self.client.get(reverse('book'))
        self.assertEqual(response.status_code, 200)

    def test_reservations_page(self):
        response = self.client.get(reverse('reservations'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'John')

    def test_bookings_api_get_all(self):
        response = self.client.get(reverse('bookings'))
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.content)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]['first_name'], 'John')

    def test_bookings_api_get_by_date(self):
        response = self.client.get(reverse('bookings') + '?date=2024-12-13')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.content)
        self.assertEqual(len(data), 1)

    def test_bookings_api_get_by_date_no_results(self):
        response = self.client.get(reverse('bookings') + '?date=2024-12-14')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.content)
        self.assertEqual(len(data), 0)

    def test_bookings_api_post_success(self):
        data = {
            'first_name': 'Jane',
            'reservation_date': '2024-12-13',
            'reservation_slot': 19
        }
        response = self.client.post(
            reverse('bookings'),
            data=json.dumps(data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Booking.objects.count(), 2)

    def test_bookings_api_post_duplicate(self):
        data = {
            'first_name': 'Jane',
            'reservation_date': '2024-12-13',
            'reservation_slot': 18  # Same as existing booking
        }
        response = self.client.post(
            reverse('bookings'),
            data=json.dumps(data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn('error', json.loads(response.content))
