from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from .models import Booking
from datetime import datetime
import json


def home(request):
    return render(request, 'index.html')


def about(request):
    return render(request, 'about.html')


def book(request):
    return render(request, 'book.html')


def reservations(request):
    bookings = Booking.objects.all()
    booking_json = serializers.serialize('json', bookings)
    return render(request, 'reservations.html', {'bookings': booking_json})


def bookings(request):
    if request.method == 'GET':
        date = request.GET.get('date')
        if date:
            bookings = Booking.objects.filter(reservation_date=date)
        else:
            bookings = Booking.objects.all()
        
        booking_list = []
        for booking in bookings:
            booking_list.append({
                'id': booking.id,
                'first_name': booking.first_name,
                'reservation_date': str(booking.reservation_date),
                'reservation_slot': booking.reservation_slot
            })
        
        return JsonResponse(booking_list, safe=False)
    
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            first_name = data.get('first_name')
            reservation_date = data.get('reservation_date')
            reservation_slot = data.get('reservation_slot')
            
            # Check if booking already exists
            if Booking.objects.filter(reservation_date=reservation_date, reservation_slot=reservation_slot).exists():
                return JsonResponse({'error': 'Slot already booked'}, status=400)
            
            booking = Booking.objects.create(
                first_name=first_name,
                reservation_date=reservation_date,
                reservation_slot=reservation_slot
            )
            
            return JsonResponse({
                'id': booking.id,
                'first_name': booking.first_name,
                'reservation_date': str(booking.reservation_date),
                'reservation_slot': booking.reservation_slot
            }, status=201)
        
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
